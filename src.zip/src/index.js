import reportWebVitals from './reportWebVitals';

ReactDOM.render(
    <React.StrictMode>
        <App />
    </React.StrictMode>,
    /React.StrictMode>,>!(document.getElementById('root')
document.getElementById(`root`)
);
reportWebVitals();


